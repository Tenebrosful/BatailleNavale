/**
 * 
 */

/**
 * @author BERNARD Hugo 'Tenebrosful'
 *
 */
public class PositionException extends GrilleException {

	/**
	 * Constructeur de PositionGrilleException.java pour 
	 */
	public PositionException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructeur de PositionGrilleException.java pour 
	 * @param arg0
	 */
	public PositionException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
