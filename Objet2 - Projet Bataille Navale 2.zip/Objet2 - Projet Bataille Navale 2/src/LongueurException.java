/**
 * 
 */

/**
 * @author BERNARD Hugo 'Tenebrosful'
 *
 */
public class LongueurException extends BateauException {

	/**
	 * Constructeur de LongueurException.java pour 
	 */
	public LongueurException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructeur de LongueurException.java pour 
	 * @param arg0
	 */
	public LongueurException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
