/**
 * 
 */

/**
 * @author BERNARD Hugo 'Tenebrosful'
 *
 */
public class BateauException extends Exception {

	/**
	 * Constructeur de BateauException.java pour 
	 */
	public BateauException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructeur de BateauException.java pour 
	 * @param arg0
	 */
	public BateauException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
