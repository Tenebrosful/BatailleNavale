import java.util.List;

/**
 * 
 */

/**
 * @author BERNARD Hugo 'Tenebrosful'
 *
 */
public class Joueur {
	
	private Grille grille;
	private List<Bateau> listeBateau;

	/**
	 * Constructeur de Joueur.java pour 
	 */
	public Joueur() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 *
	 * @param bateau
	 */
	public void placerBateau(Bateau bateau) {
		
	}
	
	/**
	 *
	 * @param ennemi
	 * @param posX
	 * @param posY
	 * @return True si le tir a pu �tre effectu�
	 * @throws PositionException 
	 */
	public boolean tirer(Joueur ennemi, int posX, int posY) throws PositionException {
		if(!ennemi.grille.positionValide(posX, posY)) {
			throw new PositionException("La position (" + posX + ";" + posY + ") est invalide"); 
		}
		if()
		return false;		
	}

}
