import java.util.List;

/**
 * Mod�lisation de la grille de jeu
 */

/**
 * @author BERNARD Hugo 'Tenebrosful'
 *
 */
public class Grille {
	
	private int tailleX;
	private int tailleY;
	private Case[][] grille;

	/**
	 * Constructeur de Grille.java par d�faut
	 */
	public Grille() {
		this.tailleX = 20;
		this.tailleY = 20;
	}

	/**
	 * Constructeur de Grille.java pour 
	 * @param tailleX
	 * @param tailleY
	 * @throws TailleException 
	 */
	public Grille(int tailleX, int tailleY) throws TailleException{
		
		if(tailleX <= 0)
			throw new TailleException("La taille en X ne peut pas �tre n�gative (" + tailleX + ")");
		if(tailleY <= 0)
			throw new TailleException("La taille en X ne peut pas �tre n�gative (" + tailleX + ")");
		
		this.tailleX = tailleX;
		this.tailleY = tailleY;
		for(int i = 0; i < tailleX; ++i) {
			for(int j = 0; j < tailleY; ++j) {
				grille[i][j] = new Case(i,j);
			}
		}
	}
	
	/**
	 * Teste s'il reste un bateau non coul� dans la grille
	 * @return True s'il reste au moins une case avec un bateau non-coul�
	 */
	public boolean avoirBateauVivant() {
		for(int i = 0; i < this.tailleX; ++i) {
			for(int j = 0; i < this.tailleY; ++j) {
				if(grille[i][j].isImpact()) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 *
	 * @param posX
	 * @param posY
	 * @return True si la position (x;y) est valide
	 */
	public boolean positionValide(int posX, int posY) {
		return (posX < 0 || posY < 0 || posX >= this.tailleX || posY >= this.tailleY);
	}
}
