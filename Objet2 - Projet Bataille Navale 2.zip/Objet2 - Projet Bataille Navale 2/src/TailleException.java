/**
 * 
 */

/**
 * @author BERNARD Hugo 'Tenebrosful'
 *
 */
public class TailleException extends GrilleException {

	/**
	 * Constructeur de TailleException.java pour 
	 */
	public TailleException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructeur de TailleException.java pour 
	 * @param message
	 */
	public TailleException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
