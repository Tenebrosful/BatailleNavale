/**
 * 
 */

/**
 * @author BERNARD Hugo 'Tenebrosful'
 *
 */
public class GrilleException extends Exception {

	/**
	 * Constructeur de GrilleException.java pour 
	 */
	public GrilleException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructeur de GrilleException.java pour 
	 * @param message
	 */
	public GrilleException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
