/**
 * Mod�lisation des bateaux
 */

/**
 * @author BERNARD Hugo 'Tenebrosful'
 *
 */
public class Bateau {
	
	private int posX;
	private int posY;
	private int longueur;
	private String orientation;
	private String nom;
	
	
	/**
	 * Porte-avion de 4 de longueur
	 */
	public static final Bateau PorteAvion = new Bateau(4,"Porte-avion");
	
	/**
	 * Sous-marin de 2 de longueur
	 */
	public static final Bateau SousMarin = new Bateau(2,"Sous-marin");
	
	/**
	 * Barque de 1 de longueur
	 */
	public static final Bateau Barque = new Bateau(1,"Barque");
	

	/**
	 * Constructeur de Bateau.java pour 
	 * @param longueur
	 * @param nom
	 * @throws LongueurException 
	 */
	public Bateau(int longueur, String nom) throws LongueurException {
		if(longueur < 0)
			throw new LongueurException("La taille d'un bateau ne peut pas �tre n�gative (" + longueur + ")");
		this.longueur = longueur;
		this.nom = nom;
	}
	
	/**
	 * Constructeur de Bateau.java pour 
	 * @param nom 
	 * @param modele
	 */
	public Bateau(String nom, Bateau modele) {
		this.nom = nom;
		this.longueur = modele.getLongueur();
	}

	/**
	 * Retourne posX
	 * @return posX
	 */
	public int getPosX() {
		return posX;
	}

	/**
	 * Retourne posY
	 * @return posY
	 */
	public int getPosY() {
		return posY;
	}

	/**
	 * Retourne longueur
	 * @return longueur
	 */
	public int getLongueur() {
		return longueur;
	}

	/**
	 * Retourne orientation
	 * @return orientation
	 */
	public String getOrientation() {
		return orientation;
	}

	/**
	 * Retourne nom
	 * @return nom
	 */
	public String getNom() {
		return nom;
	}
}
