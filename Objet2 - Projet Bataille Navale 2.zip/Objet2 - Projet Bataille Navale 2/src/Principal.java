/**
 * 
 */

/**
 * @author BERNARD Hugo 'Tenebrosful'
 *
 */
public class Principal {

	/**
	 * Constructeur de Principal.java pour 
	 */
	public Principal() {
		// TODO Auto-generated constructor stub
	}

	/**
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	/**
	 * Permet de sauvegarder la partie en cour
	 */
	public void sauvegarder() {
		
	}
	
	/**
	 *
	 * @param nomF
	 */
	public void charger(String nomF) {
		
	}
}
